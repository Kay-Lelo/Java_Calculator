package calcualator.project;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Calculator_Application {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in); 

		double fNum = 0;
		double sNum = 0;

		try {
			System.out.print("Enter you first number: ");
			fNum = sc.nextDouble();
		} catch (InputMismatchException e) {
			System.out.println("Invalid input. Enter valid number.");
			return;
		}

		try {
			System.out.print("Enter you second number: ");
			sNum = sc.nextDouble();
		} catch (InputMismatchException e) {
			System.out.println("Invalid input. Enter valid number.");
			return;
		}



		Scanner symbol = new Scanner(System.in);
		System.out.println("Enter your operator: {/, *, +, -, %}");
		char ch = symbol.next().charAt(0);

		double outcome = 0;
		switch (ch) {
		case '/': {

			if (fNum == 0) {
				System.out.println("You cannot divide by zero");
				return;
			}

			outcome = sNum / fNum;
			System.out.println("First number: " + fNum +
					"\nSecond number: " + sNum +
					"\nDivision(/): " + outcome);
			break;
		}
		case '*': {

			outcome = fNum * sNum;
			System.out.println("First number: " + fNum +
					"\nSecond number: " + sNum +
					"\nMultiplication(*): " + outcome);
			break;
		}
		case '+': {

			outcome = fNum + sNum;
			System.out.println("First number: " + fNum +
					"\nSecond number: " + sNum +
					"\nAddition(+): " + outcome);
			break;
		}

		case '-' : {

			outcome = sNum - fNum;
			System.out.println("First number: " + fNum +
					"\nSecond number: " + sNum +
					"\nSubtraction(-): " + outcome);
			break;
		}
		case '%' : {

			outcome = sNum % fNum;
			System.out.println("First number: " + fNum +
					"\nSecond number: " + sNum +
					"\nModulus(%): " + outcome);
			break;
		}
		default:

			System.out.println("Invalid operator.");
		}




	}

}
